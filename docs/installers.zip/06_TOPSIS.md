# 06 — Algoritmo TOPSIS Fuzzy

## O que é o TOPSIS Fuzzy

O TOPSIS (Technique for Order of Preference by Similarity to Ideal
Solution) com extensão Fuzzy ranqueia municípios por risco de queimada
combinando 5 critérios com pesos linguísticos. O resultado é um score
CC ∈ [0,1] onde valores próximos de 1 indicam maior risco.

**Critérios utilizados:**

| Critério | Peso | Tipo |
|---|---|---|
| Total de focos | Muito alto | Benefício |
| FRP médio (MW) | Muito alto | Benefício |
| Risco histórico | Alto | Benefício |
| Vento médio | Médio | Benefício |
| NDVI médio | Alto | Custo (invertido) |

---

## 1. Executando o TOPSIS pela interface

1. Acesse http://localhost:5173
2. Configure os filtros desejados (estado, bioma, período)
3. Clique em **Aplicar filtros**
4. Role até a seção **Análise TOPSIS Fuzzy**
5. Clique em **Executar TOPSIS Fuzzy**
6. Aguarde — o resultado aparece no painel direito e no card "Análise concluída"

---

## 2. Executando via API (curl)

### Todos os dados (sem filtro)

```bash
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{}'
```

### Filtrado por estado

```bash
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{"estado": "AM"}'
```

### Filtrado por período

```bash
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{
    "data_inicio": "2026-02-01",
    "data_fim":    "2026-04-21"
  }'
```

### Filtrado por estado, bioma e período

```bash
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{
    "estado":      "BA",
    "bioma":       "CERRADO",
    "data_inicio": "2026-02-01",
    "data_fim":    "2026-04-21"
  }'
```

### Resposta esperada

```json
{
  "mensagem": "TOPSIS Fuzzy calculado para 1575 áreas.",
  "periodo": {
    "inicio": "2025-01-02",
    "fim":    "2026-04-26"
  },
  "filtros": {
    "estado": "Todos",
    "bioma":  "Todos"
  },
  "areas_atualizadas": 1575,
  "top_5": [
    {"nome": "APUÍ/AM",            "score_topsis": 0.5001, "nivel_risco": "CRITICO", "ranking": 1},
    {"nome": "LÁBREA/AM",          "score_topsis": 0.4437, "nivel_risco": "ALTO",    "ranking": 2},
    {"nome": "TEOTÔNIO VILELA/AL", "score_topsis": 0.4306, "nivel_risco": "ALTO",    "ranking": 3},
    {"nome": "PENEDO/AL",          "score_topsis": 0.4178, "nivel_risco": "ALTO",    "ranking": 4},
    {"nome": "MAUÉS/AM",           "score_topsis": 0.4105, "nivel_risco": "ALTO",    "ranking": 5}
  ]
}
```

---

## 3. Consultando o ranking gerado

```bash
# Ranking completo
curl "http://localhost:8000/api/ranking/"

# Só os Críticos
curl "http://localhost:8000/api/ranking/?nivel_risco=CRITICO"

# Críticos do Amazonas
curl "http://localhost:8000/api/ranking/?estado=AM&nivel_risco=CRITICO"

# Ranking via banco de dados
docker compose exec db psql -U queimadas_user -d queimadas -c "
SELECT ranking, nome, score_topsis, nivel_risco, total_focos
FROM queimadas_arearisco
ORDER BY ranking
LIMIT 20;"
```

---

## 4. Classificação por níveis de risco

A classificação usa **percentis do conjunto calculado**:

| Nível | Percentil | Descrição |
|---|---|---|
| CRÍTICO | Top 10% | Municípios com maior risco relativo |
| ALTO | 10% – 25% | Risco elevado |
| MÉDIO | 25% – 50% | Risco moderado |
| BAIXO | Abaixo de 50% | Risco baixo relativo |

Com 1.575 municípios globais:

```
~158 Críticos  (10%)
~236 Altos     (15%)
~394 Médios    (25%)
~787 Baixos    (50%)
```

---

## 5. Executando o TOPSIS diretamente no Python

```bash
docker compose exec backend python manage.py shell -c "
from queimadas.topsis_fuzzy import calcular_topsis_fuzzy, NumeroFuzzy, normalizar_fuzzy

# Teste com 3 municípios
alternativas = [
    {
        'nome': 'APUI/AM', 'municipio': 'APUI', 'estado': 'AM',
        'bioma': 'AMAZONIA', 'total_focos': 27242, 'frp_media': 83.5,
        'risco_historico_medio': 0.575, 'vento_medio': 0.0, 'ndvi_medio': 0.0
    },
    {
        'nome': 'LABREA/AM', 'municipio': 'LABREA', 'estado': 'AM',
        'bioma': 'AMAZONIA', 'total_focos': 19782, 'frp_media': 72.1,
        'risco_historico_medio': 0.510, 'vento_medio': 0.0, 'ndvi_medio': 0.0
    },
    {
        'nome': 'CORURIPE/AL', 'municipio': 'CORURIPE', 'estado': 'AL',
        'bioma': 'CAATINGA', 'total_focos': 53, 'frp_media': 12.3,
        'risco_historico_medio': 0.720, 'vento_medio': 0.0, 'ndvi_medio': 0.0
    },
]

resultado = calcular_topsis_fuzzy(alternativas)
for r in resultado:
    print(f\"#{r['ranking']} {r['nome']:20} CC={r['score_topsis']:.4f}  {r['nivel_risco']}\")
"
```

---

## 6. Entendendo os scores

| Score CC | Interpretação |
|---|---|
| > 0.45 | CRÍTICO — maior concentração de focos e intensidade |
| 0.35 – 0.45 | ALTO — risco elevado |
| 0.25 – 0.35 | MÉDIO — risco moderado |
| < 0.25 | BAIXO — menor risco relativo no conjunto |

> **Nota:** Com NDVI e vento ausentes nos dados do INPE, o score máximo
> teórico é ~0.55 em vez de 1.0. A classificação por percentil
> compensa essa limitação garantindo distribuição real entre os níveis.

---

## 7. Histórico de cálculos

Cada execução do TOPSIS **substitui** o ranking anterior. Para preservar
um resultado antes de recalcular:

```bash
# Exportar ranking atual para CSV
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "\COPY (SELECT * FROM queimadas_arearisco ORDER BY ranking) \
      TO '/tmp/ranking_backup.csv' CSV HEADER;"

docker compose cp db:/tmp/ranking_backup.csv ./ranking_$(date +%Y%m%d).csv
```
