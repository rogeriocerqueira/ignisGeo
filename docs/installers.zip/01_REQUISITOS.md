# 01 — Pré-requisitos e Instalação

## Requisitos de sistema

| Componente | Versão mínima | Verificar |
|---|---|---|
| Sistema operacional | Ubuntu 20.04 / Windows 10 / macOS 12 | — |
| Docker Engine | 24.0+ | `docker --version` |
| Docker Compose | 2.20+ | `docker compose version` |
| Git | 2.30+ | `git --version` |
| RAM disponível | 4 GB mínimo, 8 GB recomendado | — |
| Disco livre | 5 GB mínimo | — |

> **Nota:** Python, Node.js e PostgreSQL **não** precisam estar instalados
> na máquina host — todos rodam dentro dos containers Docker.

---

## 1. Instalando o Docker

### Ubuntu / Debian

```bash
# Remove versões antigas
sudo apt remove docker docker-engine docker.io containerd runc

# Instala dependências
sudo apt update
sudo apt install -y ca-certificates curl gnupg

# Adiciona repositório oficial do Docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | sudo gpg --dearmor -o /usr/share/keyrings/docker.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list

# Instala Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Permite usar Docker sem sudo
sudo usermod -aG docker $USER
newgrp docker

# Verifica instalação
docker --version
docker compose version
```

### Windows

1. Baixe o **Docker Desktop** em https://www.docker.com/products/docker-desktop
2. Execute o instalador e siga as instruções
3. Reinicie o computador
4. Abra o Docker Desktop e aguarde inicializar
5. Abra o PowerShell e verifique: `docker --version`

### macOS

```bash
# Via Homebrew
brew install --cask docker

# Ou baixe o Docker Desktop em https://www.docker.com/products/docker-desktop
```

---

## 2. Clonando o repositório

```bash
# Clone o repositório
git clone https://github.com/rogeriocerqueira/ignisGeo.git

# Entre na pasta do projeto
cd ignisGeo

# Verifique a estrutura
ls -la
```

Estrutura esperada:

```
ignisGeo/
├── backend/          ← código Django
├── frontend/         ← código Vue 3
├── data/             ← arquivos CSV do INPE (criar se não existir)
├── docker-compose.yml
├── .env.example
└── .gitignore
```

---

## 3. Configurando as variáveis de ambiente

```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Edite se necessário (os valores padrão já funcionam para desenvolvimento)
nano .env
```

Conteúdo do `.env` padrão:

```env
# Banco de dados
POSTGRES_DB=queimadas
POSTGRES_USER=queimadas_user
POSTGRES_PASSWORD=queimadas_pass
POSTGRES_HOST=db
POSTGRES_PORT=5432

# Django
SECRET_KEY=sua-chave-secreta-aqui
DEBUG=True
ALLOWED_HOSTS=*

# Celery
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0
```

---

## 4. Criando a pasta de dados

```bash
# Cria a pasta para os CSVs do INPE
mkdir -p data

# Verifique se foi criada
ls data/
```

---

## 5. Verificação final

```bash
# Verifica se Docker está rodando
docker info

# Verifica se compose está disponível
docker compose version

# Verifica se o repositório está correto
git log --oneline -5
```

Se todos os comandos acima retornaram sem erro, o sistema está pronto
para inicialização. Continue para o documento `02_DOCKER.md`.
