# 07 — Frontend: Interface Vue 3

## Acessando a interface

Abra o navegador em: **http://localhost:5173**

O sistema carrega automaticamente os dados do banco ao iniciar.

---

## 1. Visão geral da interface

```
┌─────────────────────────────────────────────────────────────────┐
│  Monitor de Queimadas    INPE · TOPSIS Fuzzy · PostGIS   Dados ativos │
├───────────────────────────────────────────────────────────────────────┤
│  TOTAL DE FOCOS │ ÁREAS CRÍTICAS │ CERRADO │ MATA ATLÂNTICA │ CAATINGA│
│     191.207     │       158      │ 157.646 │     20.667     │  12.894  │
├──────────┬────────────────────────────────────────┬────────────────────┤
│ FILTROS  │                                        │ TOP ÁREAS          │
│          │         MAPA INTERATIVO                │ PRIORITÁRIAS       │
│ Estado   │                                        │                    │
│ Bioma    │  [ Focos ] [ Heatmap ] [ Áreas ]       │ #1 APUÍ/AM         │
│ Nível    │                                        │    0.5001 CRÍTICO  │
│ Data ini │                                        │ #2 LÁBREA/AM       │
│ Data fim │                                        │    0.4437 ALTO     │
│          │                                        │ ...                │
│[Aplicar] │                                        │                    │
│[Limpar ] │                                        │                    │
│──────────│                                        │                    │
│ ANÁLISE  │                                        │                    │
│ TOPSIS   │                                        │                    │
│[Executar]│                                        │                    │
└──────────┴────────────────────────────────────────┴────────────────────┘
```

---

## 2. Dashboard superior (StatsBar)

Exibe em tempo real os totais do banco, atualizando conforme os filtros:

| Card | Descrição |
|---|---|
| **Total de Focos** | Quantidade total de focos no período filtrado |
| **Áreas Críticas** | Municípios classificados como CRÍTICO (top 10%) |
| **Cerrado / Mata Atlântica / Caatinga** | Focos e FRP médio por bioma |

---

## 3. Painel de filtros (esquerda)

### Estado (UF)

- Selecione um estado para filtrar focos e ranking apenas daquela UF
- Ao selecionar um estado, o campo **Bioma** atualiza automaticamente para mostrar apenas os biomas presentes naquele estado

### Bioma

- Filtra por ecossistema
- Opções: Todos, Amazônia, Cerrado, Caatinga, Mata Atlântica, Pantanal, Pampa
- Se um estado estiver selecionado, só aparecem os biomas daquele estado

### Nível de risco

- Filtra o ranking por nível de classificação TOPSIS
- Opções: Todos, Crítico, Alto, Médio, Baixo

### Data início / Data fim

- Filtra focos pelo período de detecção
- Formato: YYYY-MM-DD (ex: 2026-02-01)

### Botões

| Botão | Ação |
|---|---|
| **Aplicar filtros** | Recarrega mapa, ranking e estatísticas com os filtros ativos |
| **Limpar** | Remove todos os filtros e recarrega os dados completos |

### Tags de filtros ativos

Abaixo dos botões aparecem tags indicando os filtros aplicados:

```
Filtros ativos: [AL] [Caatinga] [De: 2026-02-01] [Até: 2026-04-21]
```

---

## 4. Mapa interativo (centro)

### Camadas disponíveis

| Botão | Camada | Descrição |
|---|---|---|
| **Focos** | Pontos individuais | Cada ponto é um foco detectado por satélite |
| **Heatmap** | Mapa de calor | Densidade de focos ponderada pelo FRP |
| **Áreas de risco** | Polígonos | Municípios coloridos por nível TOPSIS |

### Cores dos focos (por FRP)

| Cor | FRP | Significado |
|---|---|---|
| Marrom escuro | ≥ 200 MW | Fogo muito intenso |
| Vermelho | ≥ 100 MW | Fogo intenso |
| Laranja escuro | ≥ 50 MW | Fogo moderado |
| Laranja | < 50 MW | Foco padrão |

### Legenda de áreas de risco

| Cor | Nível | Score |
|---|---|---|
| Vermelho | Crítico | ≥ 0.45 |
| Laranja escuro | Alto | 0.35 – 0.45 |
| Laranja | Médio | 0.25 – 0.35 |
| Verde | Baixo | < 0.25 |

### Interação com o mapa

- **Zoom:** scroll do mouse ou botões +/−
- **Mover:** clique e arraste
- **Popup:** clique em um ponto para ver detalhes do foco
  ```
  CORURIPE / AL
  Bioma: Caatinga
  FRP: 53.2 MW
  Data: 15/03/2026
  Satélite: NOAA-20
  ```
- **Auto-zoom:** ao aplicar filtros, o mapa centraliza automaticamente na região dos dados

---

## 5. Análise TOPSIS Fuzzy (painel esquerdo inferior)

```
ANÁLISE TOPSIS FUZZY
Calcula o ranking com base nos filtros ativos acima.

[ Executar TOPSIS Fuzzy ]

✓ Cálculo concluído
414 áreas analisadas
BA · De 2026-02-18 até 2026-04-25
Top área de risco:
BARRA/BA
Score: 0.4646 · #1
```

**Fluxo recomendado:**

1. Configure os filtros (estado, bioma, período)
2. Clique **Aplicar filtros** → veja os focos no mapa
3. Clique **Executar TOPSIS Fuzzy** → aguarde o cálculo
4. O painel direito atualiza com o novo ranking
5. O card "Áreas Críticas" no dashboard atualiza

---

## 6. Painel de ranking (direita)

Exibe as **Top 10 Áreas Prioritárias** após o cálculo TOPSIS:

```
TOP ÁREAS PRIORITÁRIAS

#1  APUÍ/AM                CRÍTICO   0.5001
    AMAZONIA · 27.242 focos

#2  LÁBREA/AM              ALTO      0.4437
    AMAZONIA · 19.782 focos

#3  TEOTÔNIO VILELA/AL     ALTO      0.4306
    MATA_ATLANTICA · 41 focos
...
```

Cada item mostra:
- Posição no ranking
- Nome do município e estado
- Bioma e total de focos
- Score TOPSIS e nível de risco

---

## 7. Hot reload (desenvolvimento)

O frontend usa **Vite Hot Module Replacement (HMR)**. Qualquer alteração
nos arquivos `.vue` ou `.js` é refletida **automaticamente** no navegador
sem necessidade de reiniciar o container ou recarregar a página.

```bash
# Verificar se o Vite está ativo
docker compose logs frontend --tail=20

# Saída esperada:
# VITE v5.x.x  ready in 312ms
# ➜  Local:   http://localhost:5173/
# ➜  Network: http://0.0.0.0:5173/
```

---

## 8. Arquivos do frontend

```
frontend/src/
├── api/index.js          ← chamadas HTTP (Axios)
├── stores/queimadas.js   ← estado global (Pinia)
├── biomas.js             ← mapeamento biomas por estado
├── components/
│   ├── App.vue           ← layout principal
│   ├── StatsBar.vue      ← dashboard de estatísticas
│   ├── FiltrosPainel.vue ← filtros e TOPSIS
│   ├── MapaQueimadas.vue ← mapa Leaflet
│   └── PainelRanking.vue ← top áreas prioritárias
└── main.js               ← inicialização Vue + Pinia
```
