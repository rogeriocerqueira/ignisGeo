# 08 — Testes Automatizados

## Visão geral

O projeto possui **41 testes automatizados** cobrindo o núcleo
matemático do TOPSIS Fuzzy, os models de dados e todos os endpoints
da API REST.

| Classe de teste | Testes | O que valida |
|---|---|---|
| `NumeroFuzzyTest` | 5 | Distância vertex, simetria, fórmula matemática |
| `NormalizarFuzzyTest` | 5 | Normalização min-max, spread, caso degenerado |
| `ClassificarNivelTest` | 4 | Thresholds de compatibilidade |
| `TopsisTest` | 9 | Algoritmo completo, ranking, percentis |
| `FocoQueimadaModelTest` | 4 | CRUD, propriedades, choices de bioma |
| `AreaRiscoModelTest` | 3 | CRUD, ordenação por ranking |
| `EstatisticasAPITest` | 2 | Endpoint `/api/estatisticas/` |
| `FocosAPITest` | 4 | Filtros, GeoJSON |
| `RankingAPITest` | 2 | Endpoint `/api/ranking/` |
| `TopsisAPITest` | 3 | POST válido, data inválida, com focos |

---

## 1. Executando os testes

```bash
# Todos os 41 testes
docker compose exec backend python manage.py test queimadas -v 2

# Com output mínimo (só falhas)
docker compose exec backend python manage.py test queimadas

# Uma classe específica
docker compose exec backend python manage.py test \
  queimadas.tests.TopsisTest -v 2

# Um teste específico
docker compose exec backend python manage.py test \
  queimadas.tests.TopsisTest.test_area_maior_risco_tem_ranking_1 -v 2
```

### Saída esperada (sucesso)

```
Found 41 test(s).
Creating test database for alias 'default' ('test_queimadas')...
...
test_criacao (queimadas.tests.NumeroFuzzyTest) ... ok
test_distancia_formula_vertex (queimadas.tests.NumeroFuzzyTest) ... ok
...
test_com_focos_calcula_ranking (queimadas.tests.TopsisAPITest) ... ok

----------------------------------------------------------------------
Ran 41 tests in 0.37s

OK
Destroying test database for alias 'default' ('test_queimadas')...
```

---

## 2. Cobertura de código

```bash
# Instalar coverage (se não instalado)
docker compose exec backend pip install coverage --break-system-packages

# Rodar com cobertura
docker compose exec backend sh -c "
  cd /app &&
  coverage run manage.py test queimadas &&
  coverage report --include='queimadas/*'
"
```

Saída esperada:

```
Name                          Stmts   Miss  Cover
-------------------------------------------------
queimadas/models.py              45      2    96%
queimadas/topsis_fuzzy.py        89      3    97%
queimadas/views.py              112      8    93%
queimadas/tasks.py               58      4    93%
queimadas/serializers.py         28      1    96%
-------------------------------------------------
TOTAL                           332     18    95%
```

---

## 3. Rodando classes individuais

```bash
# Só testes do TOPSIS (algoritmo matemático)
docker compose exec backend python manage.py test \
  queimadas.tests.TopsisTest \
  queimadas.tests.NumeroFuzzyTest \
  queimadas.tests.NormalizarFuzzyTest \
  -v 2

# Só testes da API
docker compose exec backend python manage.py test \
  queimadas.tests.TopsisAPITest \
  queimadas.tests.FocosAPITest \
  queimadas.tests.RankingAPITest \
  queimadas.tests.EstatisticasAPITest \
  -v 2

# Só testes dos models
docker compose exec backend python manage.py test \
  queimadas.tests.FocoQueimadaModelTest \
  queimadas.tests.AreaRiscoModelTest \
  -v 2
```

---

## 4. Validação matemática manual

### Distância vertex

```bash
docker compose exec backend python manage.py shell -c "
from queimadas.topsis_fuzzy import NumeroFuzzy
import math

# Teste manual da fórmula
a = NumeroFuzzy(0.0, 0.0, 0.0)
b = NumeroFuzzy(0.1, 0.2, 0.3)

resultado = a.distancia(b)
esperado  = math.sqrt((1/3) * (0.01 + 0.04 + 0.09))

print(f'Resultado: {resultado:.6f}')
print(f'Esperado:  {esperado:.6f}')
print(f'Correto:   {abs(resultado - esperado) < 0.000001}')
"
```

### Normalização fuzzy

```bash
docker compose exec backend python manage.py shell -c "
from queimadas.topsis_fuzzy import normalizar_fuzzy

# valor=50, min=0, max=100 → esperado: (0.40, 0.50, 0.60)
nf = normalizar_fuzzy(50.0, 0.0, 100.0)
print(f'a={nf.a:.2f}  b={nf.b:.2f}  c={nf.c:.2f}')
print(f'Correto: {nf.a==0.40 and nf.b==0.50 and nf.c==0.60}')
"
```

### TOPSIS completo com 2 alternativas

```bash
docker compose exec backend python manage.py shell -c "
from queimadas.topsis_fuzzy import calcular_topsis_fuzzy

alts = [
    {'nome':'Baixo', 'municipio':'Baixo', 'estado':'AL', 'bioma':'CAATINGA',
     'total_focos':10,  'frp_media':5.0,   'risco_historico_medio':0.1,
     'vento_medio':1.0, 'ndvi_medio':0.8},
    {'nome':'Alto',  'municipio':'Alto',  'estado':'AL', 'bioma':'CAATINGA',
     'total_focos':500, 'frp_media':200.0, 'risco_historico_medio':0.9,
     'vento_medio':8.0, 'ndvi_medio':0.1},
]

resultado = calcular_topsis_fuzzy(alts)
for r in resultado:
    print(f\"#{r['ranking']} {r['nome']:6} CC={r['score_topsis']:.4f}  {r['nivel_risco']}\")

# Verificações
assert resultado[0]['nome'] == 'Alto',  'ERRO: Alto deveria ser #1'
assert resultado[0]['ranking'] == 1,    'ERRO: ranking #1 incorreto'
assert resultado[0]['nivel_risco'] == 'CRITICO', 'ERRO: nível incorreto'
print('Todos os assertions passaram.')
"
```

---

## 5. Interpretando falhas

### Falha em teste matemático

```
FAIL: test_distancia_formula_vertex
AssertionError: 0.2161 != 0.2160 within 6 places
```

Indica divergência na implementação da fórmula vertex. Verifique
`topsis_fuzzy.py` na função `distancia()`.

### Falha em teste de API

```
FAIL: test_geojson_retorna_feature_collection
AssertionError: 'count' != 'FeatureCollection'
```

Indica que a paginação está ativa no endpoint GeoJSON.
Verifique se `pagination_class = None` está definido na view.

### Falha por banco

```
ERROR: test_criacao_basica
django.db.utils.ProgrammingError: relation does not exist
```

As migrations não foram aplicadas. Execute:

```bash
docker compose exec backend python manage.py migrate
```

---

## 6. Adicionando novos testes

Para adicionar um teste ao arquivo `backend/queimadas/tests.py`:

```python
class MeuNovoTest(TestCase):

    def test_minha_funcionalidade(self):
        # Arrange — prepara os dados
        alt = _alternativa("Teste", 100, 50.0, 0.5, 3.0, 0.4)
        
        # Act — executa a função
        resultado = calcular_topsis_fuzzy([alt])
        
        # Assert — verifica o resultado
        self.assertEqual(len(resultado), 1)
        self.assertEqual(resultado[0]["ranking"], 1)
        self.assertGreater(resultado[0]["score_topsis"], 0)
```

Rode apenas o novo teste:

```bash
docker compose exec backend python manage.py test \
  queimadas.tests.MeuNovoTest -v 2
```
