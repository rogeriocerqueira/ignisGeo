# IgnisGeo — Manual do Usuário

## Índice de documentos

| Arquivo | Conteúdo |
|---|---|
| `01_REQUISITOS.md` | Pré-requisitos de sistema e instalação de dependências |
| `02_DOCKER.md` | Configuração e operação do Docker Compose |
| `03_BANCO_DE_DADOS.md` | PostgreSQL + PostGIS: estrutura, conexão e manutenção |
| `04_BACKEND.md` | Django: configuração, endpoints, comandos e logs |
| `05_IMPORTACAO_DADOS.md` | Importação de dados do INPE BDQueimadas |
| `06_TOPSIS.md` | Execução do algoritmo TOPSIS Fuzzy |
| `07_FRONTEND.md` | Vue 3: instalação, uso da interface e filtros |
| `08_TESTES.md` | Execução e interpretação dos testes automatizados |
| `09_PROBLEMAS_COMUNS.md` | Troubleshooting: erros frequentes e soluções |

## Visão geral da arquitetura

```
Browser (localhost:5173)
        │
        │ HTTP / Proxy Vite
        ▼
Frontend Vue 3 (container: ignisgeo_frontend)
        │
        │ /api/* → http://backend:8000
        ▼
API Django + GeoDjango (container: ignisgeo_backend :8000)
        │                         │
        │ SQL / PostGIS            │ Celery tasks
        ▼                         ▼
PostgreSQL + PostGIS        Redis + Celery Worker
(container: ignisgeo_db)   (containers: ignisgeo_redis
      :5433                          ignisgeo_celery)
```

## Comandos rápidos (referência)

```bash
# Iniciar tudo
docker compose up -d

# Parar tudo
docker compose down

# Ver logs de todos os containers
docker compose logs -f

# Rodar testes
docker compose exec backend python manage.py test queimadas -v 2

# Acessar o sistema
http://localhost:5173
```
