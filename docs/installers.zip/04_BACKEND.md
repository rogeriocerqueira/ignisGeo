# 04 — Backend: Django + GeoDjango

## Estrutura do backend

```
backend/
├── config/
│   ├── settings.py      ← configurações Django
│   ├── urls.py          ← roteamento principal
│   ├── celery.py        ← configuração do Celery
│   └── wsgi.py
├── queimadas/
│   ├── models.py        ← FocoQueimada e AreaRisco
│   ├── views.py         ← endpoints da API REST
│   ├── serializers.py   ← serialização GeoJSON
│   ├── urls.py          ← rotas da API
│   ├── topsis_fuzzy.py  ← algoritmo TOPSIS Fuzzy
│   ├── tasks.py         ← importação CSV (Celery)
│   └── tests.py         ← 41 testes automatizados
├── manage.py
└── requirements.txt
```

---

## 1. Endpoints da API

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/focos/geojson/` | GeoJSON dos focos para o mapa |
| GET | `/api/focos/` | Lista simplificada de focos |
| GET | `/api/areas-risco/geojson/` | GeoJSON das áreas de risco |
| GET | `/api/ranking/` | Ranking TOPSIS das áreas |
| POST | `/api/calcular-topsis/` | Executa o algoritmo TOPSIS Fuzzy |
| POST | `/api/importar-csv/` | Importa CSV do INPE via Celery |
| GET | `/api/estatisticas/` | Dashboard com totais |

### Filtros disponíveis nos endpoints GET

```
?estado=AL              ← filtra por UF
?bioma=CAATINGA         ← filtra por bioma
?data_inicio=2026-02-01 ← filtra por data inicial
?data_fim=2026-04-21    ← filtra por data final
?nivel_risco=CRITICO    ← filtra por nível (só no ranking)
?bbox=-40,-12,-35,-8    ← filtra por bounding box geográfico
```

---

## 2. Testando a API via curl

```bash
# Listar focos de AL
curl "http://localhost:8000/api/focos/geojson/?estado=AL"

# Estatísticas gerais
curl "http://localhost:8000/api/estatisticas/"

# Ranking dos municípios
curl "http://localhost:8000/api/ranking/"

# Ranking filtrado por estado e nível
curl "http://localhost:8000/api/ranking/?estado=AM&nivel_risco=CRITICO"

# Calcular TOPSIS (todos os dados)
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{}'

# Calcular TOPSIS com filtros
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{"estado": "BA", "data_inicio": "2026-02-01", "data_fim": "2026-04-21"}'
```

---

## 3. Django Admin

O Django Admin permite visualizar e editar dados diretamente pelo navegador.

### Criar superusuário (primeira vez)

```bash
docker compose exec backend python manage.py createsuperuser
# Preencha: nome de usuário, email e senha
```

### Acessar o Admin

Abra: http://localhost:8000/admin/

Entre com as credenciais criadas acima.

---

## 4. Shell interativo do Django

```bash
# Abre o shell Python com contexto Django carregado
docker compose exec backend python manage.py shell

# Exemplos de uso dentro do shell:
from queimadas.models import FocoQueimada, AreaRisco

# Contar registros
FocoQueimada.objects.count()
AreaRisco.objects.count()

# Buscar focos de AL
focos_al = FocoQueimada.objects.filter(estado='AL')
print(focos_al.count())

# Top 5 municípios do ranking
ranking = AreaRisco.objects.order_by('ranking')[:5]
for a in ranking:
    print(a.ranking, a.nome, a.score_topsis, a.nivel_risco)

# Testar o TOPSIS manualmente
from queimadas.topsis_fuzzy import calcular_topsis_fuzzy, NumeroFuzzy
nf = NumeroFuzzy(0.5, 0.7, 0.9)
print(nf.a, nf.b, nf.c)
```

---

## 5. Comandos de gerenciamento

```bash
# Ver todas as migrations e status
docker compose exec backend python manage.py showmigrations

# Criar migrations após alterar models.py
docker compose exec backend python manage.py makemigrations

# Aplicar migrations
docker compose exec backend python manage.py migrate

# Verificar configurações
docker compose exec backend python manage.py check

# Ver todas as URLs registradas
docker compose exec backend python manage.py show_urls
```

---

## 6. Logs do backend

```bash
# Logs em tempo real
docker compose logs backend -f

# Últimas 50 linhas
docker compose logs backend --tail=50

# Filtrar erros
docker compose logs backend | grep -i error
docker compose logs backend | grep -i "500\|404\|403"
```

### Interpretando os logs

```
# Requisição bem-sucedida
[2026-04-27 10:30:15] "GET /api/focos/geojson/ HTTP/1.1" 200 83107

# Erro de CSRF (POST sem token)
Forbidden: /api/calcular-topsis/
"POST /api/calcular-topsis/ HTTP/1.1" 403 108

# Erro interno
"GET /api/ranking/ HTTP/1.1" 500 ...
```

---

## 7. Configurações importantes (settings.py)

| Configuração | Valor | Descrição |
|---|---|---|
| `DEBUG` | `True` | Modo desenvolvimento — mostrar erros detalhados |
| `ALLOWED_HOSTS` | `['*']` | Aceita conexões de qualquer host |
| `PAGE_SIZE` | `5000` | Máximo de registros por página |
| `TIME_ZONE` | `America/Sao_Paulo` | Fuso horário do sistema |
| `LANGUAGE_CODE` | `pt-br` | Idioma padrão |

---

## 8. Celery Worker

O Celery processa a importação de CSV de forma assíncrona.

```bash
# Ver logs do worker
docker compose logs celery -f

# Verificar se o worker está ativo
docker compose exec celery celery -A config inspect active

# Monitorar tarefas em execução
docker compose exec celery celery -A config inspect reserved
```

### Status esperado nos logs

```
ignisgeo_celery | [tasks]
ignisgeo_celery |   . queimadas.tasks.importar_csv_inpe
ignisgeo_celery | [2026-04-27 ...] Connected to redis://redis:6379/0
ignisgeo_celery | [2026-04-27 ...] celery@container ready.
```
