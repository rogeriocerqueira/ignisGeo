# 09 — Problemas Comuns e Soluções

## Diagnóstico rápido

```bash
# Verifica status de todos os containers
docker compose ps

# Verifica logs de todos
docker compose logs --tail=20

# Verifica saúde do banco
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "SELECT COUNT(*) FROM queimadas_focoqueimada;"
```

---

## Problemas com Docker

### Container não inicia

**Sintoma:** `docker compose ps` mostra container com status `Exit`

```bash
# Ver o erro detalhado
docker compose logs <nome_container> --tail=50

# Soluções mais comuns:
# 1. Porta já em uso
sudo lsof -i :8000    # backend
sudo lsof -i :5173    # frontend
sudo lsof -i :5433    # banco
# Se ocupada, mate o processo ou mude a porta no docker-compose.yml

# 2. Falta de memória
docker stats --no-stream

# 3. Recriar o container
docker compose up -d --force-recreate backend
```

### Erro "no space left on device"

```bash
# Limpa imagens e containers não utilizados
docker system prune -a

# Limpa só volumes não utilizados (CUIDADO)
docker volume prune
```

### Erro na build do backend (GDAL)

```bash
# Rebuild forçado sem cache
docker compose build --no-cache backend
docker compose up -d
```

---

## Problemas com o Banco de Dados

### "relation does not exist"

**Causa:** Migrations não foram aplicadas.

```bash
docker compose exec backend python manage.py migrate
```

### "queimadas_focoqueimada" vazia após importação

**Causa:** Arquivo CSV não encontrado ou formato incorredo.

```bash
# Verificar se o arquivo está no container
docker compose exec backend ls -lh /app/data/

# Verificar o cabeçalho do CSV
docker compose exec backend head -2 /app/data/focos.csv

# Testar parse de uma linha manualmente
docker compose exec backend python manage.py shell -c "
from queimadas.tasks import parse_linha
linha = {
    'DataHora': '2026/02/01 03:25:00',
    'Satelite': 'NOAA-20',
    'Pais': 'Brasil',
    'Estado': 'ALAGOAS',
    'Municipio': 'MESSIAS',
    'Bioma': 'Mata Atlântica',
    'DiaSemChuva': '3.0',
    'Precipitacao': '0.0',
    'RiscoFogo': '0.9',
    'FRP': '2.5',
    'Latitude': '-9.31805',
    'Longitude': '-35.79092'
}
resultado = parse_linha(linha)
print(resultado)
"
```

### Conexão recusada na porta 5433

```bash
# Verificar se o container do banco está rodando
docker compose ps db

# Ver logs do banco
docker compose logs db --tail=30

# Reiniciar o banco
docker compose restart db
```

---

## Problemas com o Backend (Django)

### Erro 403 Forbidden no POST

**Causa:** Proteção CSRF ativa.

Verifique se `@csrf_exempt` está nos decorators das views POST:

```python
# backend/queimadas/views.py
@csrf_exempt
@api_view(["POST"])
def calcular_topsis_view(request):
    ...
```

### Erro 500 Internal Server Error

```bash
# Ver o traceback completo nos logs
docker compose logs backend --tail=100

# Ativar modo debug (já deve estar True em desenvolvimento)
# backend/config/settings.py
DEBUG = True
```

### "Import could not be resolved" no VS Code (Pylance)

**Causa:** Pacotes instalados no container, não no venv local.

```bash
# Instala no venv local para silenciar o Pylance
cd backend
source .venv/bin/activate
pip install django djangorestframework djangorestframework-gis \
    celery redis numpy scipy geopandas dj-database-url \
    django-cors-headers psycopg2-binary
```

### Hot reload não funciona

```bash
# Verificar se o volume está montado corretamente
docker compose logs backend --tail=10
# Deve aparecer: "Watching for file changes with StatReloader"

# Se não aparecer, reinicie
docker compose restart backend
```

---

## Problemas com o Frontend (Vue 3)

### "Failed to resolve import" no browser

**Causa:** Arquivo referenciado não existe no projeto.

```bash
# Verificar estrutura de arquivos
find frontend/src -type f | sort

# Ver logs do Vite
docker compose logs frontend --tail=30
```

### Mapa não carrega os focos

**Causa:** API retornando dados paginados em vez de FeatureCollection.

```bash
# Testar o endpoint diretamente
curl http://localhost:8000/api/focos/geojson/ | python3 -m json.tool | head -5

# Deve retornar:
# { "type": "FeatureCollection", "features": [...] }
# Se retornar { "count": ..., "results": ... } → paginação ativa
```

Verifique em `backend/queimadas/views.py`:

```python
class FocosGeoJSONView(generics.ListAPIView):
    pagination_class = None  # ← deve existir
```

### Filtros não funcionam (mapa não atualiza)

```bash
# Abrir F12 → Network → aplicar filtro → verificar URL da request
# Deve aparecer: /api/focos/geojson/?estado=AL&bioma=CAATINGA
# Se aparecer sem params → bug na store
```

### "Carregando dados..." infinito

**Causa:** Um dos requests falhou silenciosamente.

```bash
# F12 → Console → verificar erros em vermelho
# F12 → Network → verificar requests com status 4xx ou 5xx
```

---

## Problemas com o TOPSIS

### "Erro ao calcular TOPSIS Fuzzy" no botão

```bash
# Testar via curl para ver o erro real
curl -X POST http://localhost:8000/api/calcular-topsis/ \
  -H "Content-Type: application/json" \
  -d '{}' -v

# Ver logs do backend no momento da chamada
docker compose logs backend --tail=20
```

### Ranking não atualiza após cálculo

```bash
# Verificar se há dados no banco
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "SELECT COUNT(*), nivel_risco FROM queimadas_arearisco GROUP BY nivel_risco;"

# Forçar recarga da página (Ctrl+R)
# O frontend recarrega automaticamente, mas cache do browser pode interferir
```

### Score máximo muito baixo (~0.55)

**Causa esperada:** NDVI e vento ausentes nos dados do INPE.
Isso é **normal** e documentado. A classificação por percentis
compensa essa limitação.

---

## Reset completo do ambiente

Se precisar recomeçar do zero:

```bash
# Para todos os containers
docker compose down

# Remove volumes (APAGA TODOS OS DADOS)
docker compose down -v

# Remove imagens buildadas localmente
docker rmi ignisgeo_backend ignisgeo_frontend 2>/dev/null || true

# Reinicia do zero
docker compose up --build -d

# Aplica migrations
docker compose exec backend python manage.py migrate

# Reimporta os dados
# (ver documento 05_IMPORTACAO_DADOS.md)
```

---

## Contato e repositório

- **Repositório:** https://github.com/rogeriocerqueira/ignisGeo
- **Issues:** https://github.com/rogeriocerqueira/ignisGeo/issues
- **Dados INPE:** https://queimadas.dgi.inpe.br/queimadas/bdqueimadas
