# 02 — Docker Compose

## Visão geral dos containers

| Container | Imagem | Porta | Função |
|---|---|---|---|
| `ignisgeo_backend` | `python:3.12-slim` + GDAL | `8000` | API Django |
| `ignisgeo_frontend` | `node:20-alpine` | `5173` | Interface Vue 3 |
| `ignisgeo_db` | `kartoza/postgis:16` | `5433` | Banco de dados |
| `ignisgeo_redis` | `redis:7-alpine` | `6379` | Broker Celery |
| `ignisgeo_celery` | (mesmo do backend) | — | Worker assíncrono |

---

## 1. Primeira inicialização

Execute na raiz do projeto (onde está o `docker-compose.yml`):

```bash
# Builda as imagens e inicia todos os containers
docker compose up --build

# Aguarde até ver as mensagens:
# ignisgeo_backend  | Watching for file changes with StatReloader
# ignisgeo_frontend | VITE v5.x.x  ready in Xs
```

> A primeira execução pode demorar 5 a 10 minutos pois faz o download
> das imagens e instala as dependências Python e Node.

---

## 2. Inicializações subsequentes

```bash
# Inicia em segundo plano (recomendado para uso diário)
docker compose up -d

# Verifica se todos estão rodando
docker compose ps
```

Saída esperada:

```
NAME                  STATUS          PORTS
ignisgeo_backend      Up              0.0.0.0:8000->8000/tcp
ignisgeo_celery       Up
ignisgeo_db           Up              0.0.0.0:5433->5432/tcp
ignisgeo_frontend     Up              0.0.0.0:5173->5173/tcp
ignisgeo_redis        Up              6379/tcp
```

---

## 3. Aplicar migrations (primeira vez)

Após iniciar os containers pela primeira vez:

```bash
# Gera as migrations dos models Django
docker compose exec backend python manage.py makemigrations queimadas

# Aplica as migrations no banco
docker compose exec backend python manage.py migrate

# Verifica se as tabelas foram criadas
docker compose exec backend python manage.py shell -c \
  "from queimadas.models import FocoQueimada, AreaRisco; \
   print('Focos:', FocoQueimada.objects.count(), \
         '| Áreas:', AreaRisco.objects.count())"
```

Saída esperada: `Focos: 0 | Áreas: 0`

---

## 4. Comandos essenciais do dia a dia

```bash
# Iniciar
docker compose up -d

# Parar (mantém os dados)
docker compose down

# Parar e remover volumes (APAGA OS DADOS DO BANCO)
docker compose down -v

# Reiniciar um container específico
docker compose restart backend
docker compose restart frontend
docker compose restart celery

# Ver logs em tempo real de todos
docker compose logs -f

# Ver logs de um container específico
docker compose logs backend --tail=50
docker compose logs celery --tail=50
docker compose logs db --tail=50

# Executar comando dentro de um container
docker compose exec backend <comando>
docker compose exec db <comando>
docker compose exec frontend <comando>
```

---

## 5. Rebuild após mudanças

```bash
# Após alterar requirements.txt ou package.json
docker compose up --build

# Após alterar apenas código Python ou Vue (sem rebuild)
# O hot reload já funciona automaticamente — não precisa reiniciar
```

---

## 6. Verificação de saúde dos containers

```bash
# Status resumido
docker compose ps

# Uso de recursos (CPU, memória)
docker stats

# Inspecionar um container
docker inspect ignisgeo_backend
```

---

## 7. Portas e acessos

| Serviço | URL / Endereço |
|---|---|
| Frontend (interface principal) | http://localhost:5173 |
| API Django (backend) | http://localhost:8000/api/ |
| Admin Django | http://localhost:8000/admin/ |
| PostgreSQL (DBeaver/psql) | localhost:5433 |
| Redis | localhost:6379 |

---

## 8. Solução rápida para container que não sobe

```bash
# Ver o erro detalhado
docker compose logs <nome_container> --tail=100

# Recriar apenas um container
docker compose up -d --force-recreate backend

# Recriar todos
docker compose up -d --force-recreate
```
