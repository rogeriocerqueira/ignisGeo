# 05 — Importação de Dados do INPE

## Fonte dos dados

**URL:** https://terrabrasilis.dpi.inpe.br/queimadas/bdqueimadas

Os dados são públicos e gratuitos, disponibilizados pelo Instituto
Nacional de Pesquisas Espaciais (INPE). O sistema aceita o formato
CSV padrão do BDQueimadas.

---

## 1. Baixando os dados do INPE

### Passo a passo no site

1. Acesse https://queimadas.dgi.inpe.br/queimadas/bdqueimadas
2. Na aba **Exportar Dados**, configure:
   - **País:** Brasil
   - **Estado:** escolha o estado desejado (ou deixe em branco para todos)
   - **Data início:** data de início do período
   - **Data fim:** data de fim do período
   - **Satélite:** Todos (recomendado)
3. Clique em **Exportar** → **CSV**
4. Aguarde o download do arquivo

### Formato esperado do CSV

O arquivo deve conter as seguintes colunas (cabeçalho na primeira linha):

```
DataHora,Satelite,Pais,Estado,Municipio,Bioma,DiaSemChuva,
Precipitacao,RiscoFogo,FRP,Latitude,Longitude
```

Exemplo de linha:

```
2026/02/01 03:25:00,NOAA-20,Brasil,ALAGOAS,MESSIAS,Mata Atlântica,
3.0,0.0,0.9,2.5,-9.31805,-35.79092
```

---

## 2. Preparando o arquivo para importação

```bash
# Copie o CSV para a pasta data/ do projeto
cp ~/Downloads/focos_2026.csv ./data/focos.csv

# Se tiver múltiplos CSVs, você pode importar cada um separadamente
cp ~/Downloads/focos_al.csv ./data/focos_al.csv
cp ~/Downloads/focos_ba.csv ./data/focos_ba.csv
cp ~/Downloads/focos_am.csv ./data/focos_am.csv

# Verifique se o arquivo chegou no container
docker compose exec backend ls -lh /app/data/
```

---

## 3. Importando os dados

### Método 1 — Shell Django (recomendado, mais rápido)

```bash
docker compose exec backend python manage.py shell -c "
import csv
from queimadas.models import FocoQueimada
from queimadas.tasks import parse_linha

caminho = '/app/data/focos.csv'
importados = 0
erros = 0
lote = []

with open(caminho, encoding='utf-8-sig') as f:
    reader = csv.DictReader(f)
    for linha in reader:
        dados = parse_linha(linha)
        if dados:
            lote.append(FocoQueimada(**dados))
        else:
            erros += 1
        if len(lote) >= 500:
            FocoQueimada.objects.bulk_create(lote, ignore_conflicts=True)
            importados += len(lote)
            print(f'Importados: {importados}...')
            lote = []
    if lote:
        FocoQueimada.objects.bulk_create(lote, ignore_conflicts=True)
        importados += len(lote)

print(f'Concluído: {importados} importados | {erros} erros')
print(f'Total no banco: {FocoQueimada.objects.count()}')
"
```

### Método 2 — API (assíncrono via Celery)

```bash
# O arquivo deve estar em /app/data/ dentro do container
curl -X POST http://localhost:8000/api/importar-csv/ \
  -H "Content-Type: application/json" \
  -d '{"caminho": "/app/data/focos.csv"}'
```

Resposta:

```json
{
  "mensagem": "Importação iniciada.",
  "task_id": "3f8a2b1c-...",
  "caminho": "/app/data/focos.csv"
}
```

Acompanhe o progresso nos logs do Celery:

```bash
docker compose logs celery -f
```

---

## 4. Verificando a importação

```bash
# Contagem total
docker compose exec backend python manage.py shell -c \
  "from queimadas.models import FocoQueimada; print(FocoQueimada.objects.count())"

# Detalhes por estado e período
docker compose exec db psql -U queimadas_user -d queimadas -c "
SELECT
  estado,
  COUNT(*) AS focos,
  MIN(data_hora::date) AS data_inicio,
  MAX(data_hora::date) AS data_fim
FROM queimadas_focoqueimada
GROUP BY estado
ORDER BY focos DESC;"
```

---

## 5. Dados importados no projeto (referência)

| Estado | Período | Focos | Biomas |
|---|---|---|---|
| AM (Amazonas) | jan/2025 – abr/2026 | ~162.000 | Amazônia |
| BA (Bahia) | fev/2026 – abr/2026 | ~14.000 | Caatinga, Cerrado, Mata Atlântica |
| MG (Minas Gerais) | fev/2026 – abr/2026 | ~8.000 | Cerrado, Mata Atlântica |
| PE (Pernambuco) | fev/2026 – abr/2026 | ~4.000 | Caatinga, Mata Atlântica |
| AL (Alagoas) | fev/2026 – abr/2026 | ~2.838 | Caatinga, Mata Atlântica |
| **Total** | | **~191.207** | |

---

## 6. Normalização automática dos dados

O parser `parse_linha()` realiza as seguintes normalizações automaticamente:

### Estados

| CSV (INPE) | Banco |
|---|---|
| `MINAS GERAIS` | `MG` |
| `ALAGOAS` | `AL` |
| `BAHIA` | `BA` |
| `AMAZONAS` | `AM` |
| (todos os 27 estados) | UF de 2 letras |

### Biomas

| CSV (INPE) | Banco |
|---|---|
| `Mata Atlântica` | `MATA_ATLANTICA` |
| `Amazônia` | `AMAZONIA` |
| `Cerrado` | `CERRADO` |
| `Caatinga` | `CAATINGA` |
| `Pantanal` | `PANTANAL` |
| `Pampa` | `PAMPA` |

### Valores especiais

| Situação | Tratamento |
|---|---|
| `RiscoFogo` negativo (ex: -999) | Convertido para `0.0` |
| `FRP` vazio | Convertido para `0.0` |
| Data inválida | Linha descartada (contada em erros) |
| Linha incompleta | Linha descartada |
| Registro duplicado | Ignorado silenciosamente (`ignore_conflicts`) |

---

## 7. Importando múltiplos arquivos em sequência

```bash
for arquivo in al ba mg pe am; do
  echo "=== Importando $arquivo ==="
  docker compose exec backend python manage.py shell -c "
import csv
from queimadas.models import FocoQueimada
from queimadas.tasks import parse_linha

caminho = '/app/data/focos_${arquivo}.csv'
lote = []
importados = 0

try:
    with open(caminho, encoding='utf-8-sig') as f:
        for linha in csv.DictReader(f):
            dados = parse_linha(linha)
            if dados:
                lote.append(FocoQueimada(**dados))
            if len(lote) >= 500:
                FocoQueimada.objects.bulk_create(lote, ignore_conflicts=True)
                importados += len(lote)
                lote = []
    if lote:
        FocoQueimada.objects.bulk_create(lote, ignore_conflicts=True)
        importados += len(lote)
    print(f'${arquivo}: {importados} focos importados')
except FileNotFoundError:
    print(f'Arquivo ${arquivo} não encontrado')
"
done

# Confirmação final
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "SELECT COUNT(*) AS total_focos FROM queimadas_focoqueimada;"
```
