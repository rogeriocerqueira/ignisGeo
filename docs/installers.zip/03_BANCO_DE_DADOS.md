# 03 — Banco de Dados: PostgreSQL + PostGIS

## Credenciais de acesso

| Parâmetro | Valor |
|---|---|
| Host | `localhost` |
| Porta | `5433` |
| Banco | `queimadas` |
| Usuário | `queimadas_user` |
| Senha | `queimadas_pass` |
| Driver | PostgreSQL |

---

## 1. Conectando via terminal (psql)

```bash
# Acessa o psql dentro do container
docker compose exec db psql -U queimadas_user -d queimadas

# Ou direto da máquina host (se psql instalado)
psql -h localhost -p 5433 -U queimadas_user -d queimadas
```

Comandos úteis dentro do psql:

```sql
-- Lista todas as tabelas
\dt

-- Descreve a estrutura de uma tabela
\d queimadas_focoqueimada
\d queimadas_arearisco

-- Sai do psql
\q
```

---

## 2. Conectando via DBeaver

1. Abra o DBeaver
2. Clique em **Nova Conexão** → **PostgreSQL**
3. Preencha:
   - **Host:** `localhost`
   - **Porta:** `5433`
   - **Banco:** `queimadas`
   - **Usuário:** `queimadas_user`
   - **Senha:** `queimadas_pass`
4. Clique em **Testar Conexão**
5. Se aparecer "Conectado com sucesso" → clique em **Finalizar**

---

## 3. Estrutura das tabelas

### `queimadas_focoqueimada`

```sql
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'queimadas_focoqueimada'
ORDER BY ordinal_position;
```

| Coluna | Tipo | Descrição |
|---|---|---|
| `id` | bigint | Chave primária auto-incremental |
| `localizacao` | geometry(Point,4326) | Coordenada GPS do foco (PostGIS) |
| `data_hora` | timestamptz | Data e hora da detecção pelo satélite |
| `municipio` | varchar(100) | Nome do município |
| `estado` | varchar(2) | UF (ex: AL, BA, AM) |
| `bioma` | varchar | Bioma (AMAZONIA, CERRADO, etc.) |
| `frp` | float | Fire Radiative Power em MW |
| `risco_historico` | float | Índice de risco INPE [0,1] |
| `satelite` | varchar(50) | Satélite detector (NOAA-20, etc.) |
| `vento_ms` | float | Velocidade do vento (pode ser nulo) |
| `ndvi` | float | Índice de vegetação (pode ser nulo) |

### `queimadas_arearisco`

| Coluna | Tipo | Descrição |
|---|---|---|
| `id` | bigint | Chave primária |
| `nome` | varchar(200) | Nome no formato "MUNICÍPIO/UF" |
| `geometria` | geometry(MultiPolygon,4326) | Polígono do município (pode ser nulo) |
| `estado` | varchar(2) | UF |
| `bioma` | varchar | Bioma |
| `score_topsis` | float | Score TOPSIS Fuzzy [0,1] |
| `ranking` | integer | Posição no ranking |
| `nivel_risco` | varchar | CRITICO, ALTO, MEDIO ou BAIXO |
| `total_focos` | integer | Quantidade de focos no período |
| `frp_media` | float | FRP médio dos focos |
| `risco_historico_medio` | float | Média do risco histórico |
| `periodo_inicio` | date | Início do período analisado |
| `periodo_fim` | date | Fim do período analisado |

---

## 4. Consultas úteis de diagnóstico

```sql
-- Contagem total de registros
SELECT
  (SELECT COUNT(*) FROM queimadas_focoqueimada) AS focos,
  (SELECT COUNT(*) FROM queimadas_arearisco)    AS areas;

-- Focos por estado
SELECT estado, COUNT(*) AS total
FROM queimadas_focoqueimada
GROUP BY estado
ORDER BY total DESC;

-- Focos por bioma
SELECT bioma, COUNT(*) AS total, ROUND(AVG(frp)::numeric, 2) AS frp_medio
FROM queimadas_focoqueimada
GROUP BY bioma
ORDER BY total DESC;

-- Intervalo de datas dos dados importados
SELECT
  MIN(data_hora::date) AS data_inicio,
  MAX(data_hora::date) AS data_fim
FROM queimadas_focoqueimada;

-- Distribuição do ranking por nível de risco
SELECT nivel_risco, COUNT(*) AS municipios
FROM queimadas_arearisco
GROUP BY nivel_risco
ORDER BY municipios DESC;

-- Top 10 municípios por score TOPSIS
SELECT nome, score_topsis, nivel_risco, total_focos, ranking
FROM queimadas_arearisco
ORDER BY ranking
LIMIT 10;

-- Focos com maior FRP
SELECT municipio, estado, frp, data_hora::date
FROM queimadas_focoqueimada
ORDER BY frp DESC
LIMIT 10;

-- Verificar se PostGIS está ativo
SELECT PostGIS_Version();
```

---

## 5. Migrations Django

```bash
# Ver status das migrations
docker compose exec backend python manage.py showmigrations

# Criar nova migration após alterar models.py
docker compose exec backend python manage.py makemigrations queimadas

# Aplicar migrations pendentes
docker compose exec backend python manage.py migrate

# Desfazer uma migration específica (cuidado!)
docker compose exec backend python manage.py migrate queimadas 0001
```

---

## 6. Backup e restore

```bash
# Backup completo do banco
docker compose exec db pg_dump -U queimadas_user queimadas \
  > backup_$(date +%Y%m%d).sql

# Restore de um backup
docker compose exec -T db psql -U queimadas_user -d queimadas \
  < backup_20260427.sql

# Backup só da tabela de focos
docker compose exec db pg_dump -U queimadas_user \
  -t queimadas_focoqueimada queimadas \
  > backup_focos_$(date +%Y%m%d).sql
```

---

## 7. Limpar dados sem remover o banco

```bash
# Apaga todos os focos (mantém estrutura)
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "TRUNCATE queimadas_focoqueimada RESTART IDENTITY CASCADE;"

# Apaga só as áreas de risco (ranking)
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "TRUNCATE queimadas_arearisco RESTART IDENTITY CASCADE;"

# Apaga tudo e reinicia IDs
docker compose exec db psql -U queimadas_user -d queimadas \
  -c "TRUNCATE queimadas_focoqueimada, queimadas_arearisco RESTART IDENTITY CASCADE;"
```

---

## 8. Extensão PostGIS

O PostGIS permite consultas espaciais nativas:

```sql
-- Focos dentro de um bounding box (lon_min, lat_min, lon_max, lat_max)
SELECT municipio, estado, frp
FROM queimadas_focoqueimada
WHERE ST_Within(
  localizacao,
  ST_MakeEnvelope(-40, -12, -35, -8, 4326)
)
ORDER BY frp DESC
LIMIT 20;

-- Verificar índice espacial
SELECT indexname FROM pg_indexes
WHERE tablename = 'queimadas_focoqueimada'
  AND indexname LIKE '%localizacao%';
```
